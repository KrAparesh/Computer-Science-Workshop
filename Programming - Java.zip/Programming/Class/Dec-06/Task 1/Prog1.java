import java.util.*;
public class Prog1 {
    public static void main(String[] args) {
        ArrayList myList = new ArrayList();
        String str = "This is my string!";
        Integer I = Integer.valueOf(10);
        Integer I2 = Integer.valueOf(20);
        myList.add(I);
        myList.add(I2);
        System.out.println(I == I2);
        System.out.println(myList.get(1));
    }    
}
