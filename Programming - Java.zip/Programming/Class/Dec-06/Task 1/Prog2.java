public class Prog2 {
    public static void main(String[] args) {
        Integer I1 = Integer.valueOf("130");
        System.out.println(I1.intValue());
        System.out.println(I1.doubleValue());
        System.out.println(I1.floatValue());
        System.out.println(I1.longValue());
        System.out.println(I1.shortValue());
        System.out.println(I1.byteValue());
    }
}
