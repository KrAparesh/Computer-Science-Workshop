// Write a program which contains a generic class, constructor and a generic method.


import java.util.*;

class MyGeneric<T>{
    T ob;
    MyGeneric(T ob){
        this.ob = ob;
    }

    public void showType(){
        System.out.println("The object type is: " + ob);
    }

    public T checkData(T newData){
        if(newData.toString().equals(ob.toString())){
            System.out.println("The value is true!");
            return newData;
        }
        System.out.println("This is a generic method");
        System.out.println("The value of the object is: " + ob);
        return ob;
    }

}

public class Prog_1 {
    public static void main(String[] args) {
        MyGeneric obj = new MyGeneric("Hi");
        obj.showType();
        obj.checkData("Hi");
    }
}
