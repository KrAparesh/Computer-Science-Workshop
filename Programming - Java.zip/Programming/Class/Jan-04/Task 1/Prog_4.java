// Write a program for a generic class. Pass two type parameters, String and Integer
// and then show it's output


class MyGeneric<T, G>{
    T ob_T; G ob_G;
    MyGeneric(T ob_T, G ob_G){
        this.ob_T = ob_T;
        this.ob_G = ob_G;
    }

    public void show(){
        System.out.println("Object T:" + ob_T);
        System.out.println("Object G:" + ob_G);
    }

}

public class Prog_4 {
    public static void main(String[] args) {
        MyGeneric <Integer, String> ob = new MyGeneric<Integer, String>(10, "Hey!");
        System.out.println("The integer output is: " + ob.ob_T);
        System.out.println("The String output is: " + ob.ob_G);

    }
}
