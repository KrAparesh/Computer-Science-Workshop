import java.util.*;
public class getPowerSet {
    public List<List<Integer>> subsets(int[] nums) {
        List subset = new 
    }    
}
