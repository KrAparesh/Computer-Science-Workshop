// Write a program to create a class with student details. Create an object for that class and print 
// that object. Create a constructor too.

import java.util.*;
class Student {
    String name, subject;
    int RollNo;

    Student(String name, int RollNo, String subject){
        this.name = name;
        this.RollNo = RollNo;
        this.subject = subject;    
    }

    public void show(){
        System.out.println("Student name: " + name + "\n Student Roll No.: " + RollNo + "\n Subject: " + subject);
    }


    
}

class myCustom extends Object {

    @Override
    public String toString(){
        return "Hi";
    }

}   
public class Prog_5{
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Student ob = new Student("Aparesh Kumar", 20, "CSW");
        Student ob2 = new Student("Aparesh Kumar", 20, "CSW");
        System.out.println("The student details are: " + ob.name +" | "+ ob.RollNo + " | " + ob.subject);
        System.out.println("Object: " + ob);
        System.out.println("Object to string: " + ob.toString());
        System.out.println("Object's hashed: " + ob.hashCode());
        System.out.println(ob.equals(ob2));
    }
}
