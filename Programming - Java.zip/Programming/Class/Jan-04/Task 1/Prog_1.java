import java.util.*;
public class Prog_1 {
    public static void main(String[] args) {
        
        ArrayList ar = new ArrayList();
        Integer objectInt = new Integer(10);
        ar.add(10);
        ar.add(objectInt);
        ar.add("This is a statement");
        String fromint = (String)ar.get(0);
        // String fromintobj = (String)ar.get(1);
        // String fromstr = (String)ar.get(2);
        System.out.println(fromint + " " );
        
    }    
}
