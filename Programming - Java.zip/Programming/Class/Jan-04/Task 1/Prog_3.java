class Test<T>{
    T obj;
    Test(T obj){
        this.obj = obj;
    }

    public void show() {
        System.out.println(obj);
    }
}

public class Prog_3 {   
    public static void main(String[] args) {
        Test<String> ob= new Test<String>("0");
        Test<Integer> ob2 = new Test<Integer>(0);
        System.out.println("Object 1: " + ob.obj + " Object 2: " + ob2.obj);

    }    
}
