import java.util.*;

class customHash<K, V>{
    K ob_key; V ob_value;
    HashMap<K, V> myCustomHash = new HashMap<K, V>();
}

public class Prog_6 extends customHash{
    public static void main(String[] args) {

        // customHash<Integer, String> myob = new customHash<Integer, String>();
        // customHash<String, String> myob2 = new customHash<String, String>();
        // myob.myCustomHash.put(1, "one");
        // myob2.myCustomHash.put("Hello", "Hola!");
        // System.out.println(myob2.myCustomHash);

        HashMap<Integer, String> myMap = new HashMap<Integer, String>();
        myMap.put(1, "one");
        myMap.put(2, "two");
        myMap.put(3, "three");
        myMap.put(4, "four");
        myMap.put(5, "five");
        System.out.println("Original map:" + myMap);
        if(myMap.containsKey(3)){
            myMap.remove(3);
        }
        myMap.put(6, "six");

        //Accessing the elements in the hashmap

        Set mySet = myMap.entrySet();
        Iterator myPointer = mySet.iterator();
        
        while(myPointer.hasNext()){
            Map.Entry element = Map.Entry(mypo) 
            System.out.println("Key: " + )
        }
    }    
}
