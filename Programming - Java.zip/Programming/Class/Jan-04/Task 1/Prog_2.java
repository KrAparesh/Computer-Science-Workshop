import java.util.*;
public class Prog_2 {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<String>();
        list.add(10); //Can't add an integer value to this arrayList.
        list.add("This is a test statement");
        System.out.println(list.get(0));

    }
}
