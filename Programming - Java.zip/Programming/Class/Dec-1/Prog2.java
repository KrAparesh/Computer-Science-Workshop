public class Prog2{
    public static int[][] multiply(int arr1[][], int arr2[][]){
        int result[][] = new int[arr1.length][arr1.length];
        int temp = 0, i = 0, j = 0;
        if(arr1[0].length != arr2[0].length){
            System.out.println("Cannot be multiplied");
            return null;
        }
        System.out.println("The first array matrix is: ");
        for(i = 0; i < arr1.length; i++){
            for(j = 0; j < arr1[0].length; j++){
                System.out.print(arr1[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("The second array matrix is: ");
        for(i = 0; i < arr2.length; i++){
            for(j = 0; j < arr2[0].length; j++){
                System.out.print(arr2[i][j] + " ");
            }
            System.out.println();
        }

        System.out.println("The multiplied matrix is: ");
        for(i = 0 ; i < arr1.length; i++){
            for(j = 0; j < arr1[0].length; i++){
                temp += arr1[i][j] * arr2[j][i];   
                System.out.print(arr1[i][j] * arr2[j][i] + " ");   
            }
            result[i][j] = temp;
            temp = 0;
        }
        for(i = 0; i < result.length; i++){
            for(j = 0; j < result[0].length; j++){
                System.out.print(result[i][j] + " ");
            }
            System.out.println();
        }
        return null;
    }

    public static void main(String[] args) {
        int a[][] = {{1,2,3},{2,3,4},{3,4,5}};
        int b[][] = {{1,2,3},{2,3,4},{3,4,5}};
        multiply(a, b); 
    }
}