for(int i = 0 ; i < arr1.length; i++){
        //     for(int j = 0; j < arr1.length; i++){
        //         result[i][j] = {arr1.}
        //     }
        // }