import java.util.*;

public class Prog1 {
    enum Day {
        Sunday(0), 
        Monday(1), 
        Tuesday(2), 
        Wednesday(3), 
        Thursday(4), 
        Friday(5);
        Day(int day){}
        
    }
    static Day myDay;
    public static void main(String[] args) {
        switch(myDay){
            case Sunday:System.out.println("Sunday!");break;
            default: System.out.println("This is a default message");break;
        }
    }
}
