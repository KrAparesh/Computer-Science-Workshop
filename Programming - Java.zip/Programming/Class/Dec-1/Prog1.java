public class Prog1 {
    public static void main(String[] args) {
        int arr1[] = {1, 2, 3, 4, 5, 6, 7, 8};
        int arr2[] = {8, 7, 6, 5, 4, 3, 2, 1};
        System.out.print("The summation of the array is: ");
        for(int i = 0; i < (Math.min(arr1.length, arr2.length)); i++){
            System.out.print(arr1[i] + arr2[i] + " ");
        }
        System.out.println();
    }    
}
