//HashSet

import java.util.*;
public class Prog_1 {
    public static void main(String[] args) {
        HashSet<Integer> mySet = new HashSet<Integer>();
        mySet.add(10);
        mySet.add(5);
        mySet.add(20);
        mySet.add(null);
        mySet.add(null);
        System.out.println(mySet);
    }
}
