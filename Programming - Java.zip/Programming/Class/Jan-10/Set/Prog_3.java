import java.util.*;
class Prog_3{
    public static void main(String[] args) {
        Vector<Integer> myVect = new Vector<Integer>();
        myVect.add(10);
        myVect.add(20);
        myVect.add(30);
        myVect.add(40);
        System.out.println(myVect + "\n" + "Vector capacity: " + myVect.capacity());
    }
}