//Treeset

import java.util.*;
public class Prog_2 {
    public static void main(String[] args) {
        TreeSet<String> mySet = new TreeSet<String>();
        mySet.add("B");
        mySet.add("C");
        mySet.add("D");
        mySet.add("Bd");
        mySet.add("A");
        // mySet.add(null);
        // mySet.add(null);
        System.out.println(mySet);
    }
}
