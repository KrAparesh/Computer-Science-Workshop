import java.util.*;
class Prog_4{
    public static void main(String[] args) {
        LinkedList<Integer> myVect = new LinkedList<Integer>();
        myVect.add(10);
        myVect.add(20);
        myVect.add(30);
        myVect.add(40);
        System.out.println(myVect);
    }
}