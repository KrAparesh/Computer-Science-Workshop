// TreeMap:

import java.util.*;
class Prog_3{
    public static void main(String[] args) {
        TreeMap<Integer, String> hmap = new TreeMap<Integer, String>();
        hmap.put(10, "A");
        hmap.put(20, "B");
        hmap.put(5, "C");
        hmap.put(10, "D");
        hmap.put(30, "A");
        hmap.put(40, null);
        hmap.put(50, null);
        System.out.println(hmap);
    }   
}