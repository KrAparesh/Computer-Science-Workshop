import java.util.*;
class Prog_1{
    public static void main(String[] args) {
        PriorityQueue<Integer> myQ = new PriorityQueue<Integer>();
        myQ.add(10);
        myQ.add(20);
        myQ.add(40);
        myQ.add(30);
        System.out.println(myQ.peek());
        System.out.println(myQ);
        System.out.println(myQ.poll());
        System.out.println(myQ);
        System.out.println(myQ.peek());
        System.out.println(myQ);
        System.out.println(myQ.poll());
        System.out.println(myQ);
    }
}