public class Prog_3 {
    public static void main(String[] args) {
        StringBuffer s1 = new StringBuffer("Hola!");
        StringBuilder s2 = new StringBuilder("Hola!");
        long starttime = System.currentTimeMillis();
        for(int i = 0 ; i < 100000; i++){
            s1.append("Java");
        }
        System.out.println("Time taken by StringBuffer: " + (System.currentTimeMillis() - starttime));

        starttime = System.currentTimeMillis();
        for(int i = 0; i < 100000; i++){
            s2.append("Java");
        }
        System.out.println("Time taken by StringBuilder: " + (System.currentTimeMillis() - starttime));

    }    
}
