import java.util.*;
class Prog_1{
    public static void main(String[] args) {
        String literal1 = "xyz";
        String literal2 = "xyz";
        System.out.print("Comparison using == operator for literals: ");
        System.out.println(literal1 == literal2);
        
        String keyword1 = new String("abc");
        String keyword2 = new String("abc");
        System.out.println("Comparison using == operator for objects: " + keyword1 == keyword2);
    }
}