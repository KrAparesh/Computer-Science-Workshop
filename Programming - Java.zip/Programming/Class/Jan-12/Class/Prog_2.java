public class Prog_2 {
    public static void main(String[] args) {
        String myStr = "My Favorite Programming language : Java";
        String[] arrofStr = myStr.split(":");
        for(String piece : arrofStr){
            System.out.println(piece);
        }
    }    
}
