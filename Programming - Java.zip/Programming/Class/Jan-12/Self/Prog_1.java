import java.io.*;



public class Prog_1 {
    
}
