import java.util.*;
class myClass implements Runnable{
    public void run() {
        System.out.println("My method is running!");
        for(int i = 0 ; i < 10 ; i++){
            System.out.println("i = " + i);
        }
    }  
}
public class Prog_1 extends myClass{  
    public static void main(String[] args) {
        // Prog_1 myob = new Prog_1();
        myClass obj = new myClass();
        Thread myThread = new Thread(obj);
        myThread.start();
        // myThread.start(); IllegalThreadStateException
        // myob.run();
        for(int j = 0 ; j < 10 ; j++){
            System.out.println("j = " + j);
        }
    }   
}

