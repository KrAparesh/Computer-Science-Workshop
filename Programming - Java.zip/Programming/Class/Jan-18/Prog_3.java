import java.util.*;

class yo extends Thread {
    public void run(){
        for(int i = 1 ; i < 4 ; i++){
            try {
                Thread.sleep(500);
            } catch (InterruptedException e){
                System.out.println(e);
            }
            System.out.println(i);
        }
    }
}

public class Prog_3 {
    public static void main(String[] args) {
        yo ob = new yo();
        ob.start();
        System.out.println(Thread.currentThread().getName());
        ob.start();
        System.out.println(Thread.currentThread().getName());
    }
}

