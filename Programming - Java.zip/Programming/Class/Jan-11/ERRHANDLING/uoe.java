import java.util.*;
class uoe {
    private String myObject;
    public static void main(String[] args) {
        testMethod1();
        System.gc();
    }
    public uoe(String myObject){
        this.myObject = myObject;
    }
    private static void testMethod1(){
        uoe myObjectTest1 = new uoe("myObjectTest1");
        System.out.println("This method was called");
    }

    @Override
    protected void finalize()throws Throwable{
        System.out.println("Garbage collection is successfull for " + this.myObject);
    }
}