public class mygc {
   private String myObject;
   public mygc(String myObject){
    this.myObject = myObject;
   }
   public static void main(String args[]){
    mygc testObject1 = new mygc("testObject1");
    mygc testObject2 = new mygc("testObject2");
    testObject1 = testObject2;
    System.gc();
   }
   @Override
   protected void finalize() throws Throwable{
    System.out.println("Garbage collection is successfull for " + this.myObject);
   }
}
