import java.util.*;

class AgeException extends Exception {
    AgeException(String error){
        super(error);
    }
}

public class Prog_2 {
    public static void main(String[] args) {
        int age = 13;
        try{
            if(age < 15)
                throw new AgeException("Baccha hai ye");    
        } catch(Exception e) {
            System.out.println(e);
        }
        
    }
}
