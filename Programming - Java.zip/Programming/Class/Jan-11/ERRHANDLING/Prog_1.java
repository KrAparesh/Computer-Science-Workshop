import java.util.*;
public class Prog_1 {
    public static void main(String[] args) {
        int a = 10, b = 0;
        int c;

        try{
            c = a / b;
            System.out.println(c);
        } catch(ArithmeticException e){
            System.out.println("Not Possible!");
        }
        finally{
            System.out.println("This will always execute");
        }
        System.out.println("End of code!");
    }    
}
