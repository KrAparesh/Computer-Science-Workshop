import java.util.*;
public class anonymous {
    String ab;
    public anonymous(String ab){
        this.ab = ab;
    }    
    public int myMethod(String inp){
        new anonymous(inp);
        return 1;
    }
    public static void main(String[] args) {
        anonymous ob = new anonymous("Hi");
        System.out.println(ob.myMethod("hello"));
        
    }
}
