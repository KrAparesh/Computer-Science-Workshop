//Write a program for a calculator by using interface

interface calculator {
    public int sum (int a, int b);
    public int difference (int a, int b);
    public int multiply (int a, int b);
    public double divide (int a, int b);
}

public class Prog_2{
    
    public static void main(String[] args) {
        calculator ob = new calculator() {
            @Override
            public int sum(int a, int b) {
                return a + b;
            }
        
            @Override
            public int difference(int a, int b) {
                return a + b;
            }
        
            @Override
            public int multiply(int a, int b) {
                return a * b;
            }
        
            @Override
            public double divide(int a, int b) {
                return a / b;
            }     
        };
        
        System.out.println(ob.sum(1, 2) + "\n" + ob.difference(4, 5) + "\n" +  ob.multiply(4, 5) + "\n" + ob.divide(4, 20));
    }
}
