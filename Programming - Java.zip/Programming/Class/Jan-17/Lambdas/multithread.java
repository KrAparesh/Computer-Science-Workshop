class pqr {
    public static synchronized void ab(String name){
        for(int i = 0; i <= 5; i++){
        try{
            Thread.sleep(100);
        }
        catch(Exception e){ }
            System.out.println(name);
        }
    }
    
    public void abc (String name){
        for(int i = 0 ; i <= 5; i++) {
            try{
                Thread.sleep(100);
            }
            catch(Exception e) { }
                System.out.println(name);
        }
    }
}

class myThread extends Thread {
    pqr p;
    String name;
    myThread(pqr p, String name){
        this.p = p;
        this.name = name;
    }
    public void run() {
        p.ab(name);
    }
}

// class myThread2 extends Thread {
//     pqr p;
//     String name;
//     myThread2(pqr p, String name){
//         this.p = 
//     }
// }

public class multithread {
    public static void main(String argsp[]){
        pqr p = new pqr();
        myThread m1 = new myThread(p, "Hello");
        myThread m2 = new myThread(p , "Hiiiiiiiiiiiiiiiiiiiiiiii");
        m1.start();
        m2.start();
    }
}
