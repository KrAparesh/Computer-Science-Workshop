public class LambdaExpressionUsingReturn {
    interface reportCard {
        // Adding multiple parameters to the method
        public int marksForSubjects(int mathematics, int physics, int biology, int history,
                int chemistry);
    }

public static void main(String[] args) {
reportCard am1=(int mathematics,int physics,int biology,int history, int
chemistry)->(mathematics + physics + biology + history+ chemistry); 
;
System.out.println("The total of the first student is "+am1.
marksForSubjects(74,87,66,53,90));
reportCard am2=(int mathematics,int physics,int biology,int history, int
chemistry)->{
return (mathematics + physics + biology + history+ chemistry);
};
System.out.println("The total of the second student is "+am2.
marksForSubjects(40,40,50,60,70));
reportCard am3=(int mathematics,int physics,int biology,int history, int
chemistry)->{
return (mathematics + physics + biology + history+ chemistry);
};
System.out.println("The total of the third student is "+am3.
marksForSubjects(50,60,70,60,70));
reportCard am4=(int mathematics,int physics,int biology,int history, int chemistry)->{
return (mathematics + physics + biology + history+ chemistry);
};
System.out.println("The total of the fourth student is "+am4.
marksForSubjects(65,56,95,65,78));
reportCard am5=(int mathematics,int physics,int biology,int history, int
chemistry)->{
return (mathematics + physics + biology + history+ chemistry);
};
System.out.println("The total of the fifth student is "+am5.
marksForSubjects(85,86,55,75,88));
}
}