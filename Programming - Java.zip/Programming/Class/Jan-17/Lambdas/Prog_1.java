interface myFuncs {
    public int sum (int a, int b);
}

public class Prog_1{
    public static void main(String[] args) {
        myFuncs c = (int a, int b) -> (a + b);
        System.out.println(c.sum(5,2));
    }

}