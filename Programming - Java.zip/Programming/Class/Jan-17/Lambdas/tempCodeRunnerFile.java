public void abc (String name){
    //     for(int i = 0 ; i <= 5; i++) {
    //         try{
    //             Thread.sleep(100);
    //         }
    //     }
    // }