public class Subtract {
    private int beginningValue = 2;

    public int sub(int x) {
        // the original value is modified by addition
        return beginningValue + x;
    }
    public static void main(String[] args) {
        Subtract ob=new Subtract();
        System.out.println(ob.sub(3));
        System.out.println(ob.sub(3));
    }
}