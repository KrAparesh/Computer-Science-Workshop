import java.util.*;
class Q9 {
    public static int encodeLiteral(String literal){
        int result = 0, i = 0;
        while(i < literal.length()){
            result += (((int)literal.toUpperCase().charAt(i)) % 64);
            i++;
        }
        return result;    
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number to get it's encoded value: ");
        String inp = sc.next();
        System.out.println("The encoded value of " + inp + " is " + encodeLiteral(inp));
    }
}