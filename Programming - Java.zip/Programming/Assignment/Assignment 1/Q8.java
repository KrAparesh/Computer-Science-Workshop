public class Q8 {
    // Convert to Binary string and then apply full adder technique to get addition of 3 bit number. 
    // Then convert that binary output to decimal
    // Skipping at the moment
}
